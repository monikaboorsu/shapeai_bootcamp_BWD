import React from "react";

function Note() {
  return (
    <div className="note">
      <h1>Bootcamp of Javascript and React.js</h1>
      <p>
        This bootcamp is of Web development with Javascript and React.js for 7 days .
        This was really an amazing bootcamp from Shaurya sir and we really learned a lot from this bootcamp .
        We are interested in participating in upcoming bootcamps by SHAPE AI .
        </p>
    </div>
  );
}

export default Note;
